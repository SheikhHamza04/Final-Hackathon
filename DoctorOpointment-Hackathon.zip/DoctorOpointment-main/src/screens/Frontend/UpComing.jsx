import { View, Text } from 'react-native'
import React from 'react'

export default function UpComing() {
  return (
    <View>
      <Text>UpComing</Text>
    </View>
  )
}